﻿using System.Windows;
using Microsoft.Phone.Controls;

namespace PedroLamas.SmartWrapListDemo
{
    public partial class WrapPanelPage : PhoneApplicationPage
    {
        public WrapPanelPage()
        {
            InitializeComponent();

            Loaded += PageLoaded;
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            var items = DataModel.GetItems();

            ItemsListBox.ItemsSource = items;
        }
    }
}