﻿using System;
using System.ComponentModel;
using System.Windows;
using Cimbalino.Phone.Toolkit.Extensions;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Info;

namespace PedroLamas.SmartWrapListDemo
{
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void WrapPanelButton_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/WrapPanelPage.xaml", UriKind.Relative));
        }

        private void SmartWrappingButton_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/SmartWrappingPage.xaml", UriKind.Relative));
        }

        protected override void OnBackKeyPress(CancelEventArgs e)
        {
            MessageBox.Show("Peak memory: {0:N0}k".FormatWithInvariantCulture(DeviceStatus.ApplicationPeakMemoryUsage / 1024));

            base.OnBackKeyPress(e);
        }
    }
}