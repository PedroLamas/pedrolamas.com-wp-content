﻿using System.Linq;
using System.Windows;
using Cimbalino.Phone.Toolkit.Extensions;
using Microsoft.Phone.Controls;

namespace PedroLamas.SmartWrapListDemo
{
    public partial class SmartWrappingPage : PhoneApplicationPage
    {
        public SmartWrappingPage()
        {
            InitializeComponent();

            Loaded += PageLoaded;
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            var items = DataModel.GetItems()
                .Batch(3)
                .Select(x => x.ToList());

            ItemsListBox.ItemsSource = items;
        }
    }
}