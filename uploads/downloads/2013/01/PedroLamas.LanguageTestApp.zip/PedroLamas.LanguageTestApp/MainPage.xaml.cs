﻿using System.Threading;
using Microsoft.Phone.Controls;

namespace PedroLamas.LanguageTestApp
{
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            Language = System.Windows.Markup.XmlLanguage.GetLanguage(Thread.CurrentThread.CurrentUICulture.Name);

            InitializeComponent();

            this.DataContext = this;
        }

        public string CurrentCulture
        {
            get
            {
                return Thread.CurrentThread.CurrentCulture.Name;
            }
        }

        public string CurrentUICulture
        {
            get
            {
                return Thread.CurrentThread.CurrentUICulture.Name;
            }
        }
    }
}